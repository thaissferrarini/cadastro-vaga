import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-I3HX573K.js";
import "./chunk-UPAX5JPO.js";
import "./chunk-2GLYIHSY.js";
import "./chunk-6IQOKCZY.js";
import "./chunk-JCUL4FUC.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-CT6PALCU.js";
import "./chunk-YOINYF2N.js";
import "./chunk-4D5Y63HG.js";
import "./chunk-4J25ECOH.js";
import "./chunk-WKYGNSYM.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
