import {
  Paginator,
  PaginatorModule
} from "./chunk-MT5RBZVG.js";
import "./chunk-ASWKO4PP.js";
import "./chunk-LICHHK53.js";
import "./chunk-E36DSBKN.js";
import "./chunk-IHMKT4LD.js";
import "./chunk-7T5UNCQM.js";
import "./chunk-PSOBNKYR.js";
import "./chunk-5YQUKYRN.js";
import "./chunk-I3HX573K.js";
import "./chunk-UPAX5JPO.js";
import "./chunk-2GLYIHSY.js";
import "./chunk-6IQOKCZY.js";
import "./chunk-SM25LJYE.js";
import "./chunk-JCUL4FUC.js";
import "./chunk-PLJDTHQT.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-CT6PALCU.js";
import "./chunk-YOINYF2N.js";
import "./chunk-4D5Y63HG.js";
import "./chunk-4J25ECOH.js";
import "./chunk-WKYGNSYM.js";
export {
  Paginator,
  PaginatorModule
};
//# sourceMappingURL=primeng_paginator.js.map
