import {
  InputText,
  InputTextModule
} from "./chunk-LICHHK53.js";
import "./chunk-PSOBNKYR.js";
import "./chunk-CT6PALCU.js";
import "./chunk-YOINYF2N.js";
import "./chunk-4D5Y63HG.js";
import "./chunk-4J25ECOH.js";
import "./chunk-WKYGNSYM.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
