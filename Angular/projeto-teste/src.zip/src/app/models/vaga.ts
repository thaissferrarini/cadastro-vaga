export interface Vaga {
    id?: number;
    titulo: string;
    descricao: string;
    requisito: string;
    status: string;
    adm: string;
  }