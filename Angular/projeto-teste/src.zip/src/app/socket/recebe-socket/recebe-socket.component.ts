import { Component, OnInit } from '@angular/core';
import { WebSocketService } from '../../services/WebSocketService';

@Component({
  selector: 'app-recebe-socket',
  templateUrl: './recebe-socket.component.html',
})
export class RecebeSocketComponent implements OnInit {
  message: string;

  constructor(private webSocketService: WebSocketService) { }

  ngOnInit() {
    this.webSocketService.getMessages('/topic/applications').subscribe((message) => {
      console.log({menssgemUsuarioSimplesAplicou: message });
      this.message = message;
    });
  }

  public approveApplication(userId: number): void {
    const approvalMessage = { userId, message: 'Você foi aprovado para a vaga!' };
    this.webSocketService.sendMessage('/app/approval', JSON.stringify(approvalMessage));
  }
}