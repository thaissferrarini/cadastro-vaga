import { Component, OnInit } from '@angular/core';
import { WebSocketService } from '../../services/WebSocketService';

@Component({
  selector: 'app-envio-socket',
  templateUrl: './envio-socket.component.html',
})
export class EnvioSocketComponent implements OnInit {
  user = { nome: 'Nome do usuário',  menssagem: 'Usuário se inscreveu na vaga N° 321' };

  constructor(private webSocketService: WebSocketService) { }

  ngOnInit() {
    this.webSocketService.getMessages('/topic/approvals').subscribe((message) => {
      console.log('Você foi aprovado para a vaga:', message);
    });
  }
  public sendApplication(): void {
    console.error('sendApplication')
    this.webSocketService.sendMessage('/app/application', JSON.stringify(this.user));
  }
}