import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { VagasListComponent } from './vagas/vagas-list/vagas-list.component';
import { VagasDetailComponent } from './vagas/vagas-detail/vagas-detail.component';
import { VagasFormComponent } from './vagas/vagas-form/vagas-form.component';
import { AuthGuard } from './auth/auth.guard';
import { EnvioSocketComponent } from './socket/envio-socket/envio-socket.component';
import { RecebeSocketComponent } from './socket/recebe-socket/recebe-socket.component';
import { VagasCandidatoComponent } from './vagas/vagas-candidato/vagas-candidato.component';
 

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'vagas', component: VagasListComponent, canActivate: [AuthGuard] },
  { path: 'vagas/create', component: VagasFormComponent, canActivate: [AuthGuard] },
  { path: 'vagas/:id', component: VagasDetailComponent, canActivate: [AuthGuard] },
  { path: 'vagas/edit/:id', component: VagasFormComponent, canActivate: [AuthGuard] },
  { path: 'envio', component: EnvioSocketComponent, canActivate: [AuthGuard] },
  { path: 'recebe', component: RecebeSocketComponent, canActivate: [AuthGuard] },
  { path: 'inscricoes', component: VagasCandidatoComponent, canActivate: [AuthGuard] },
  
  //{ path: 'applications', component: ApplicationListComponent },
  //{ path: 'candidato-dashboard', component: CandidatoDashboardComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
