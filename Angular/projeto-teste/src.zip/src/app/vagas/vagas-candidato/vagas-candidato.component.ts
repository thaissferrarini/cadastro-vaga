import { Component, OnInit } from '@angular/core';
import { VagasService } from '../../services/vagas.service';
import { AplicacaoService } from '../../services/aplicacao.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-vagas-candidato',
  templateUrl: './vagas-candidato.component.html',
  styleUrls: ['./vagas-candidato.component.css']
})
export class VagasCandidatoComponent implements OnInit {
  vagas: any[] = [];

  constructor(
    private aplicacaoService: AplicacaoService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.carregarVagas();
  }

  carregarVagas(): void {
    const idCandidato = this.authService.getUsuarioId();
    this.aplicacaoService.getAplicacoesCandidato(idCandidato).subscribe(dados => {
      this.vagas = dados;
    });
  }

  getStatusSeverity(status: string): "success" | "info" | "warning" | "danger" {
    switch (status.toLowerCase()) {
      case 'aprovado':
        return 'success';
      case 'pendente':
        return 'warning';
      case 'rejeitado':
        return 'danger';
      default:
        return 'info';
    }
  }
}