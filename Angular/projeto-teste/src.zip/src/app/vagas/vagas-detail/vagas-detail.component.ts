import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VagasService } from '../../services/vagas.service';
import { AuthService } from '../../services/auth.service';
import { AplicacaoService } from '../../services/aplicacao.service';
import { Usuario } from '../../models/usuario';
import { Aplicacao } from '../../models/aplicacao';
import { WebSocketService } from '../../services/WebSocketService';

@Component({
  selector: 'app-vagas-detail',
  templateUrl: './vagas-detail.component.html',
  styleUrls: ['./vagas-detail.component.css']
})
export class VagasDetailComponent implements OnInit {
  vagas: any = {};
  isAdmin: boolean = false;
  candidatos: Aplicacao[]=[];
  status: boolean = true;

  constructor(
    private route: ActivatedRoute,
    private vagasService: VagasService,
    private aplicacaoService: AplicacaoService,
    private authService: AuthService,
    private router: Router,
    private webSocketService: WebSocketService,

  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.vagasService.getVagasById(Number(id)).subscribe(data => {
      this.vagas = data;
    });
    this.isAdmin = this.authService.getTipoUsuario() === 'ADMIN';
    this.usuariosAplicacao();
  }

  applyForVaga(vagaId: number): void {
    const username = this.authService.getNomeUsuario();
    const aplicacaoDTO = { vagaId: vagaId, username: username }; // Supondo que o userId seja 1 para exemplo
    this.aplicacaoService.applyForVaga(aplicacaoDTO).subscribe(
      (response) => {
        console.log('Aplicação realizada com sucesso', response);
      },
      (error) => {
        console.error('Erro ao realizar aplicação', error);
      }
    );
  }

  usuariosAplicacao() {
    const id = this.route.snapshot.paramMap.get('id');
    this.aplicacaoService.usuariosAplicacao(id).subscribe(
      (response) => {
        this.candidatos = response;
        // const status = this.candidatos[0].vaga.status;
        // if (status == "Fechada") {
        //   this.status = false;
        // }
        console.log('Aplicação realizada com sucesso', response);
      },
      (error) => {
        console.error('Erro ao realizar aplicação', error);
      }
    );
  }

  aprovarCandidato(atualiza: Aplicacao){
    atualiza.status = 'Aprovado';
    this.aplicacaoService.atualizaStatus(atualiza).subscribe(
      (response) => {
        this.avisarCanditatoAprovado(atualiza.usuario.id, atualiza.vaga.titulo)
        
        this.candidatos = response;
        const status = this.candidatos[0].vaga.status;
        if (status == "Fechada") {
          this.status = false;
        }

        console.log('Aplicação realizada com sucesso', response);
      },
      (error) => {
        console.error('Erro ao realizar aplicação', error);
      }
    );
  }


   avisarCanditatoAprovado(userId: string, vaga): void {
    const approvalMessage = { usuario: userId, nome: vaga, menssagem: 'Você foi aprovado para a vaga!' };
    this.webSocketService.sendMessage('/app/approval', JSON.stringify(approvalMessage));
  }

   avisarCanditatoReprovado(userId: string, vaga): void {
    const approvalMessage = { usuario: userId, nome: vaga, menssagem: 'Você foi reprovado para a vaga!' };
    this.webSocketService.sendMessage('/app/approval', JSON.stringify(approvalMessage));
  }

  reprovarCandidato(atualiza: Aplicacao){
    atualiza.status = 'Reprovado';
    this.aplicacaoService.atualizaStatus(atualiza).subscribe(
      (response) => {
        this.avisarCanditatoReprovado(atualiza.usuario.id, atualiza.vaga.titulo)
        this.candidatos = response;
        this.usuariosAplicacao();
        console.log('Aplicação realizada com sucesso', response);
      },
      (error) => {
        console.error('Erro ao realizar aplicação', error);
      }
    );
  }

  deleteVagas() {
    const id = this.route.snapshot.paramMap.get('id');
    this.vagasService.deleteVagas(Number(id)).subscribe(() => {
      this.router.navigate(['/vagas']);
    });
  }

  getStatusSeverity(status: string): "success" | "info" | "warning" | "danger" {
    switch (status.toLowerCase()) {
      case 'aprovado':
        return 'success';
      case 'pendente':
        return 'warning';
      case 'rejeitado':
        return 'danger';
      default:
        return 'info';
    }
  }

}